export class LiveResult {
  matchId?: number;

  entryAdded?: Date;

  goalsTeam1?: number;

  goalsTeam2?: number;
}
