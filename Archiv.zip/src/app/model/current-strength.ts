export class CurrentStrength {
  playerId?: number;

  currentDateTime?: Date;

  strength?: number;
}
