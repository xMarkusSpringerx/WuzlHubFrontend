import {Player} from "./player";
export class Team {
  id?: number;

  player1?: Player;

  player2?: Player;
}
