export class Tournament {

  id?: number;

  date?: Date;

  name?: string;

  countdownSeconds?: number;
}
